# EscapeRoom
Download all the thing and start ProtoType.ex in Debug folder.  
res folder : bitmat images  
lib folder : libraries  
include folder : headers  
  
Quite hard to get out of the room, I'm sure :)  
